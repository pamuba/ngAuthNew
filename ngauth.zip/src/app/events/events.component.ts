import { Component } from '@angular/core';
import { EventService } from '../event.service';

@Component({
  selector: 'app-events',
  standalone: false,
  templateUrl: './events.component.html',
  styleUrl: './events.component.css'
})
export class EventsComponent {
 events:any = []
 constructor(private _eventService:EventService){}

 ngOnInit(){
  this._eventService.getEvents()
    .subscribe({
      next:res => this.events = res,
      error:err => console.log(err)
    })
 }
}
