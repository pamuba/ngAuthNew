import { Component } from '@angular/core';
import { EventService } from '../event.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-special-events',
  standalone: false,
  templateUrl: './special-events.component.html',
  styleUrl: './special-events.component.css'
})
export class SpecialEventsComponent {
  specialEvents:any = []
  constructor(private _eventService:EventService, 
    private router:Router, private _auth:AuthService
  ){}
  
   ngOnInit(){
    this._eventService.getSpecialEvents()
      .subscribe({
        next:res => this.specialEvents = res,
        error:err => {
          console.log(err.message)
          if(err){
            //if(err.status == 401){
              this._auth.logoutLogin();
            //}
          }
        }
      })
   }
}
