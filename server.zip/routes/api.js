const express = require('express')
const jwt = require('jsonwebtoken')
const cors = require('cors')
const router = express.Router()
const User = require('../models/user')
const mysql = require('mysql');
const mongoose = require('mongoose')

//const db = "mongodb+srv://partha:partha39@cluster0.oi0mibo.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
//mongodb+srv://<db_username>:<db_password>@cluster0.oi0mibo.mongodb.net/
//const db = "mongodb+srv://partha:partha39@cluster0.oi0mibo.mongodb.net/authdb"
const db = "mongodb://localhost:27017/authdb"
mongoose.connect(db)
    .then(()=>console.log('Connected to the DB'))
    .catch(err => console.log('Error ', err))


function verifyToken(req, res, next){
  if(!req.headers.authorization){
    return res.status(401).send("Unauthorized request");
  }

  let token = req.headers.authorization.split(' ')[1];
  if(token == null){
    return res.status(401).send("Unauthorized request");
  }
  let payload = jwt.verify(token, 'secretKey')
  if(!payload){
    return res.status(401).send("Unauthorized request");
  }
  req.userId = payload.subject
  next()
}

//localhost:3000/api
router.get('/', (req, res) => {
    res.send("From the API route");
})

router.post('/register', (req, res)=>{
    console.log('Register')
    let userData = req.body;
    let user = new User(userData)
    user.save()
    .then(registeredUser => {
      let payload = {subject: registeredUser._id}
      let token = jwt.sign(payload, 'secretKey')
      res.status(200).send({token})
    })
    .catch(err => res.status(500).json({error:err}))
})

router.post('/login', (req, res)=>{
    let userData = req.body;
    User.findOne({email:userData.email})
    .then(user=>{
        if(!user){
                res.status(401).send('Invalid Email')
        }
        else
        {
            if(user.password !== userData.password)
            {
                res.status(401).send('Invalid Password')
            }
            else{
                    let payload = {subject: user._id}
                    let token = jwt.sign(payload, 'secretKey', {
                      expiresIn:'1m'
                    })
                    res.status(200).send({token})
            }
        }
    })
    .catch(error => console.log('User doesnt exist'))
})

router.get('/users', (req, res)=>{
    User.find({})
    .exec()
    .then(users => res.json(users))
    .catch(err => res.status(500).json({error:err}))
})

router.get('/events', (req, res)=>{
    let events = [
        {
            "_id": "1",
            "name": "Auto Expo",
            "description": "lorem ipsum",
            "date": "2012-04-23T18:25:43.511Z"
          },
          {
            "_id": "2",
            "name": "Auto Expo",
            "description": "lorem ipsum",
            "date": "2012-04-23T18:25:43.511Z"
          },
          {
            "_id": "3",
            "name": "Auto Expo",
            "description": "lorem ipsum",
            "date": "2012-04-23T18:25:43.511Z"
          },
          {
            "_id": "4",
            "name": "Auto Expo",
            "description": "lorem ipsum",
            "date": "2012-04-23T18:25:43.511Z"
          },
          {
            "_id": "5",
            "name": "Auto Expo",
            "description": "lorem ipsum",
            "date": "2012-04-23T18:25:43.511Z"
          },
          {
            "_id": "6",
            "name": "Auto Expo",
            "description": "lorem ipsum",
            "date": "2012-04-23T18:25:43.511Z"
          }
    ]
    res.json(events)
})


router.get('/special', verifyToken, (req, res)=>{
    let events = [
        {
            "_id": "1",
            "name": "Auto Expo",
            "description": "lorem ipsum",
            "date": "2012-04-23T18:25:43.511Z"
          },
          {
            "_id": "2",
            "name": "Auto Expo",
            "description": "lorem ipsum",
            "date": "2012-04-23T18:25:43.511Z"
          },
          {
            "_id": "3",
            "name": "Auto Expo",
            "description": "lorem ipsum",
            "date": "2012-04-23T18:25:43.511Z"
          },
          {
            "_id": "4",
            "name": "Auto Expo",
            "description": "lorem ipsum",
            "date": "2012-04-23T18:25:43.511Z"
          },
          {
            "_id": "5",
            "name": "Auto Expo",
            "description": "lorem ipsum",
            "date": "2012-04-23T18:25:43.511Z"
          },
          {
            "_id": "6",
            "name": "Auto Expo",
            "description": "lorem ipsum",
            "date": "2012-04-23T18:25:43.511Z"
          }
    ]
    res.json(events)
})

module.exports = router