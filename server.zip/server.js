const express = require('express')
const cors = require("cors")
const PORT = 3000
const api = require('./routes/api')


const app = express()
app.use(cors())


// app.use(cors({
//     origin:"http://localhost:4200",
//     methods:["GET","POST","PUT","DELETE"],
//     allowedHeaders:["Content-Type","Authorization"]
// }));
app.use(express.json())



//localhost:3000/api
app.use('/api', api);
app.get('/', function(req,res){
    res.send('Message from Server')
})

app.listen(PORT, function(){
    console.log("Server listening at POST: "+PORT)
})